/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestor.de.bibliotecas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author df335
 */
public class Cliente {
    
    public void Mostrar_Datos_Personales(String correo, JTextField nombre, JTextField dni, JTextField email, JTextField telefono, JPasswordField contraseña){
        
        Connection con = Conexion.conectar();
        
        String sql = "SELECT nombre_completo, dni, email, telefono, contraseña FROM usuario WHERE email = ?";
        
        try{
            
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, correo);
            
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                nombre.setText(rs.getString("nombre_completo"));
                dni.setText(rs.getString("dni"));
                email.setText(rs.getString("email"));
                telefono.setText(rs.getString("telefono"));
                contraseña.setText(rs.getString("contraseña"));
            }
            
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al mostrar datos personales.");
        }
        
        
    }
    
    public void Modificar_Datos_Personales(JTextField nombre, JTextField dni, JTextField email, JTextField telefono, JPasswordField contraseña){
        
        Connection con = Conexion.conectar();
        String sql = "UPDATE usuario SET nombre_completo = ?, email = ?, telefono = ?, contraseña = ? WHERE dni = ?";
        
        String pass = new String(contraseña.getPassword());
        
        try{
            
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, nombre.getText());
            ps.setString(2, email.getText());
            ps.setString(3, telefono.getText());
            ps.setString(4, pass);
            ps.setString(5, dni.getText());
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Datos actualizados correctamente.");
            
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al modificar datos.");
        }
        
    }
    
}
