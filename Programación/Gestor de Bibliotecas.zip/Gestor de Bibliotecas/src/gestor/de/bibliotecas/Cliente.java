/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestor.de.bibliotecas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.regex.Pattern;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JSpinner;
import javax.swing.JTextField;

/**
 *
 * @author df335
 */
public class Cliente {
    
    public void Mostrar_Datos_Personales(String correo, JTextField nombre, JTextField dni, JTextField email, JTextField telefono, JPasswordField contraseña){
        
        Connection con = Conexion.conectar();
        
        String sql = "SELECT nombre_completo, dni, email, telefono, contraseña FROM usuario WHERE email = ?";
        
        try{
            
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, correo);
            
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                nombre.setText(rs.getString("nombre_completo"));
                dni.setText(rs.getString("dni"));
                email.setText(rs.getString("email"));
                telefono.setText(rs.getString("telefono"));
                contraseña.setText(rs.getString("contraseña"));
            }
            
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al mostrar datos personales.");
        }
        
        
    }
    
    public void Modificar_Datos_Personales(JTextField nombre, JTextField dni, JTextField email, JTextField telefono, JPasswordField contraseña){
        
        Connection con = Conexion.conectar();
        String sql = "UPDATE usuario SET nombre_completo = ?, email = ?, telefono = ?, contraseña = ? WHERE dni = ?";
        
        String pass = new String(contraseña.getPassword());
        
        String validacion_telefono = "^[0-9]{9}$";
        
        if(!Pattern.matches(validacion_telefono, telefono.getText()) & !telefono.getText().equals("")){
            JOptionPane.showMessageDialog(null, "El teléfono no es válido.");
            return;
        }
        
        String validacion_correo = "^[A-Za-z0-9]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        
        if(!Pattern.matches(validacion_correo, email.getText())){
            JOptionPane.showMessageDialog(null, "Correo no válido.");
            return;
        }
        
        try{
            
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, nombre.getText());
            ps.setString(2, email.getText());
            ps.setString(3, telefono.getText());
            ps.setString(4, pass);
            ps.setString(5, dni.getText());
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Datos actualizados correctamente.");
            
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al modificar datos.");
        }
        
    }
    
    public void Catalogo_Libros(javax.swing.JPanel Catalogo_Libros, java.awt.Image imgEscalada){
        
        Connection con = Conexion.conectar();
        
        Catalogo_Libros.removeAll();
        
        try{
            
            String sql = "SELECT titulo, precio, id_editorial, id_categoria from libro";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                
                String id_editorial = rs.getString("id_editorial");
                String id_categoria = rs.getString("id_categoria");
                
                String Obtener_Editorial = "SELECT nombre FROM editorial WHERE id_editorial = ?";
                PreparedStatement ps1 = con.prepareStatement(Obtener_Editorial);
                ps1.setString(1, id_editorial);
                ResultSet rs1 = ps1.executeQuery();
                
                String editorial = "";
                
                if(rs1.next()){
                editorial = rs1.getString("nombre");
                }
                
                String Obtener_Categoria = "SELECT nombre FROM categoria WHERE id_categoria = ?";
                PreparedStatement ps2 = con.prepareStatement(Obtener_Categoria);
                ps2.setString(1, id_categoria);
                ResultSet rs2 = ps2.executeQuery();
                
                String categoria = "";
                
                if(rs2.next()){
                categoria = rs2.getString("nombre");
                }
                
                String nombre = rs.getString("titulo");
                String precio = rs.getString("precio");
                precio = (precio + " €");
                
                Info_Libro libro = new Info_Libro(nombre, editorial, categoria, precio, imgEscalada);    
                Catalogo_Libros.add(libro);
            }
            
            Catalogo_Libros.revalidate();
            Catalogo_Libros.repaint();
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    
    public void Mostrar_ISBN(JLabel mostrar, String libro){
        
        Connection con = Conexion.conectar();
        
        try{
            
            String sql = "SELECT isbn FROM libro WHERE titulo = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, libro);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                
                mostrar.setText(rs.getString("isbn"));
                
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar ISBN.");
            e.printStackTrace();
        }
        
    }
    
    public void Comprar_Libro(JSpinner cantidad, JLabel isbn){
        
        Connection con = Conexion.conectar();
        
        try{
            
            String sql = "SELECT stock FROM libro WHERE isbn = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, isbn.getText());
            ResultSet rs = ps.executeQuery();
            int stock = 0;
            if(rs.next()){
                stock = rs.getInt("stock");
            }
            
            int cant = (Integer) cantidad.getValue();
            
            if(cant < stock){
                
                String cambiar_stock = "UPDATE libro SET stock = stock - ? WHERE isbn = ?";
                PreparedStatement ps1 = con.prepareStatement(cambiar_stock);
                ps1.setInt(1, cant);
                ps1.setString(2, isbn.getText());
                ps1.executeUpdate();
                JOptionPane.showMessageDialog(null, "Compra realizada correctamente.");
                
            } else {
                JOptionPane.showMessageDialog(null, "No hay suficiente stock,  stock: " + stock);
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al comprar libro.");
            e.printStackTrace();
        }
        
    }
    
}
