
package gestor.de.bibliotecas;
import java.sql.*;

public class Conexion {
    static String url = "jdbc:mysql://192.168.1.135:3306/biblioteca";
    static String user = "usuario";
    static String pass = "1234";
    
    public static Connection conectar(){
        Connection con = null;
        try{
            con = DriverManager.getConnection(url,user,pass);
            System.out.println("Conexion correcta");
        }catch(SQLException e){
            e.printStackTrace();
        }
            return con;
    }
    
    
}
