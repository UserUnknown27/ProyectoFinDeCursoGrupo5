/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestor.de.bibliotecas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.regex.Pattern;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author df335
 */
public class Empleado {
    
    public void cargar_clientes(JComboBox lista){
     Connection con = Conexion.conectar();
    
    String sql = "SELECT dni, nombre_completo FROM usuario WHERE tipo = 'cliente'";
    try{
       lista.removeAllItems();
       lista.addItem("    --  Seleccione un Cliente  --");
       
       PreparedStatement ps = con.prepareStatement(sql);
       ResultSet rs = ps.executeQuery();
       while(rs.next()){
           String dni = rs.getString("dni");
           String nombre = rs.getString("nombre_completo");
           String cliente = dni + " | " + nombre;
           lista.addItem(cliente);
    }
    }catch(Exception e){
         e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al cargar clientes.");
    }
    }
    
    public void mostrar_datos_clientes(JComboBox lista, JTextField nombre, JTextField email, JTextField telefono){
        if(lista.getSelectedItem() == null){
           return;
       }
       
       String seleccion = lista.getSelectedItem().toString();
       
       String[] dato= seleccion.split("\\|");
       
       try{
           
           String sql = "SELECT * FROM usuario WHERE dni = ? AND tipo = 'cliente'";
           
           Connection con = Conexion.conectar();
           
           PreparedStatement ps = con.prepareStatement(sql);
           ps.setString(1, dato[0]);
           
           ResultSet rs = ps.executeQuery();
           if(rs.next()){
               
               String nom = rs.getString("nombre_completo");
               String em = rs.getString("email");
               String tel = rs.getString("telefono");
               
               nombre.setText(nom);
               email.setText(em);
               telefono.setText(tel);
           } else{
               nombre.setText("");
               email.setText("");
               telefono.setText("");
           }
           
       }catch(Exception e){
           e.printStackTrace();
           JOptionPane.showMessageDialog(null, "Error al mostrar datos.");
       }
    }
    
    public void modificar_cliente(JComboBox lista, JTextField nombre, JTextField email, JTextField telefono){
        
    if (lista.getSelectedItem().equals("    --  Seleccione un Cliente  --")) {
    JOptionPane.showMessageDialog(null, "Debes seleccionar un cliente.");
    return;
    }
    
    
    if(nombre.getText().equals("")){
        JOptionPane.showMessageDialog(null, "El nombre no puede estar vacío.");
        return;
    }
    
    String validacion_telefono = "^[0-9]{9}$";
        
        if(!Pattern.matches(validacion_telefono, telefono.getText()) & !telefono.getText().equals("")){
            JOptionPane.showMessageDialog(null, "El teléfono no es válido.");
            return;
        }
    
    String valido = "^[A-Za-z0-9]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
    
    if(Pattern.matches(valido, email.getText())){

    String seleccion = lista.getSelectedItem().toString();

    if (seleccion.equals("    --  Seleccione un Cliente  --")) {
        JOptionPane.showMessageDialog(null, "Elija un cliente por favor.");
        return;
    }

    String[] dato = seleccion.split("\\|");
    String dni = dato[0].trim();

    try {
        String sql = "UPDATE usuario SET dni = ?, nombre_completo = ?, email = ?, telefono = ? WHERE dni = ? AND tipo = 'cliente'";
        
        Connection con = Conexion.conectar();
        PreparedStatement ps = con.prepareStatement(sql);
        
        ps.setString(1, dni);
        ps.setString(2, nombre.getText());
        ps.setString(3, email.getText());
        ps.setString(4, telefono.getText());
        ps.setString(5, dni);
        
        ps.executeUpdate();
        JOptionPane.showMessageDialog(null, "Datos actualizados.");
        
        int posicion = lista.getSelectedIndex();
        
        String datos_nuevos = dni + " | " + nombre.getText();
        
        lista.removeItemAt(posicion);
        lista.insertItemAt(datos_nuevos, posicion);
        
        lista.setSelectedIndex(posicion);
        
    } catch(Exception e){
        JOptionPane.showMessageDialog(null, "Error al actualizar los datos.");
        e.printStackTrace();
    }
    
    } else{
        JOptionPane.showMessageDialog(null, "Correo no válido.");  
       }
}
    
    public void eliminar_cliente(JComboBox lista){
        Connection con = Conexion.conectar();
        String seleccion = lista.getSelectedItem().toString();
        
        String [] dato = seleccion.split("\\|");
        String dni = dato[0].trim();
        
        try{
            String sql = "DELETE FROM usuario WHERE dni = ? AND tipo = 'cliente'";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, dni);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Cliente eliminado correctamente.");
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al eliminar cliente.");
            e.printStackTrace();
        }
    }
    
    public void filtro_clientes(JComboBox lista, JTextField filtro){
        String busqueda = filtro.getText();
        Connection con = Conexion.conectar();
        
        try{
            
            lista.removeAllItems();
            
            if(busqueda.equals("")){
            lista.addItem("    --  Seleccione un Cliente  --");
            }
            
            String sql = "SELECT dni, nombre_completo FROM usuario WHERE tipo = 'cliente' AND nombre_completo LIKE ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + busqueda + "%");
            
            ResultSet rs = ps.executeQuery();
            String dni;
            String nombre;
            while(rs.next()){
                dni = rs.getString("dni");
                nombre = rs.getString("nombre_completo");
                String resultado = dni + " | " + nombre;
                lista.addItem(resultado);
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void Mostrar_en_Tabla(JComboBox tablas, JTable tabla){
        
        Connection con = Conexion.conectar();
        String seleccion = tablas.getSelectedItem().toString();
        
        DefaultTableModel modelo = new DefaultTableModel();
        
        if (seleccion.equals("Usuarios")){
           
            try{
                
                modelo.setRowCount(0);
                modelo.setColumnCount(0);
                
                modelo.addColumn("Id");
                modelo.addColumn("Tipo");
                modelo.addColumn("Nombre");
                modelo.addColumn("DNI");
                modelo.addColumn("Email");
                modelo.addColumn("Telefono");
                
                String sql = "SELECT id_usuario, tipo, nombre_completo, dni, email, telefono FROM usuario";
                
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();
                
                while(rs.next()){
                    Object[] fila = new Object[6];
                    fila[0] = rs.getString("id_usuario");
                    fila[1] = rs.getString("tipo");
                    fila[2] = rs.getString("nombre_completo");
                    fila[3] = rs.getString("dni");
                    fila[4] = rs.getString("email");
                    fila[5] = rs.getString("telefono");
                    modelo.addRow(fila);
                }
                
                tabla.setModel(modelo);
                
            }catch(Exception e){
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "No se puede cargar la tabla de usuarios.");
            }   
        }
        
        if(seleccion.equals("Libros")){
            
            try{
                
                modelo.setRowCount(0);
                modelo.setColumnCount(0);
                
                modelo.addColumn("Id");
                modelo.addColumn("Título");
                modelo.addColumn("ISBN");
                modelo.addColumn("Precio");
                modelo.addColumn("Stock");
                modelo.addColumn("ID_Edi");
                modelo.addColumn("ID_Cat");
                
                String sql = "SELECT * FROM libro";
                
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();
                while(rs.next()){
                    Object[] fila = new Object[7];
                    fila[0] = rs.getString("id_libro");
                    fila[1] = rs.getString("titulo");
                    fila[2] = rs.getString("isbn");
                    fila[3] = rs.getString("precio");
                    fila[4] = rs.getString("stock");
                    fila[5] = rs.getString("id_editorial");
                    fila[6] = rs.getString("id_categoria");
                    modelo.addRow(fila);
                }
                
                tabla.setModel(modelo);
                
            }catch(Exception e){
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "No se puede cargar la tabla de libros.");
            }
            
        }
        
        if(seleccion.equals("Editoriales")){
            
            try{
                
                modelo.setRowCount(0);
                modelo.setColumnCount(0);
                
                modelo.addColumn("Id");
                modelo.addColumn("Nombre");
                
                String sql = "SELECT * FROM editorial";
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();
                while(rs.next()){
                    Object[] fila = new Object[2];
                    fila[0] = rs.getString("id_editorial");
                    fila[1] = rs.getString("nombre");
                    modelo.addRow(fila);
                }
                
                tabla.setModel(modelo);
                
            }catch(Exception e){
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "No se puede cargar la tabla de editoriales.");
            }
            
        }
        
        if(seleccion.equals("Categorías")){
            
            try{
                
                modelo.setRowCount(0);
                modelo.setColumnCount(0);
                
                modelo.addColumn("Id");
                modelo.addColumn("Nombre");
                
                String sql = "SELECT * FROM categoria";
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();
                while(rs.next()){
                    Object[] fila = new Object[2];
                    fila[0] = rs.getString("id_categoria");
                    fila[1] = rs.getString("nombre");
                    modelo.addRow(fila);
                }
                
                tabla.setModel(modelo);
                
            }catch(Exception e){
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "No se puede cargar la tabla de categorías.");
            }
            
        }
        
    }
    
    public void Filtrar_Tablas(JComboBox combobox, JTable tabla, JTextField filtro){
        
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
        modelo.setRowCount(0);
    
        String busqueda = filtro.getText();
        Connection con = Conexion.conectar();
        String seleccion = combobox.getSelectedItem().toString();
        
        if(busqueda.equals("")){
            Mostrar_en_Tabla(combobox,tabla);
            return;
        }

    try {
        
        if (seleccion.equals("Usuarios")) {
            String sql = "SELECT * FROM usuario WHERE nombre_completo LIKE ? OR dni LIKE ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + busqueda + "%");
            ps.setString(2, "%" + busqueda + "%");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Object[] fila = new Object[6];
                fila[0] = rs.getString("id_usuario");
                fila[1] = rs.getString("tipo");
                fila[2] = rs.getString("nombre_completo");
                fila[3] = rs.getString("dni");
                fila[4] = rs.getString("email");
                fila[5] = rs.getString("telefono");
                modelo.addRow(fila);
            }
        }
        
        if (seleccion.equals("Libros")) {
            String sql = "SELECT * FROM libro WHERE titulo LIKE ? OR isbn LIKE ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + busqueda + "%");
            ps.setString(2, "%" + busqueda + "%");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Object[] fila = new Object[7];
                fila[0] = rs.getString("id_libro");
                fila[1] = rs.getString("titulo");
                fila[2] = rs.getString("isbn");
                fila[3] = rs.getDouble("precio");
                fila[4] = rs.getInt("stock");
                fila[5] = rs.getInt("id_editorial");
                fila[6] = rs.getInt("id_categoria");
                modelo.addRow(fila);
            }
        } 
        if (seleccion.equals("Clientes")) {
            String sql = "SELECT * FROM usuario WHERE tipo = 'cliente' AND (nombre_completo LIKE ? OR dni LIKE ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + busqueda + "%");
            ps.setString(2, "%" + busqueda + "%");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Object[] fila = new Object[4];
                fila[0] = rs.getString("dni");
                fila[1] = rs.getString("nombre_completo");
                fila[2] = rs.getString("email");
                fila[3] = rs.getString("telefono");
                modelo.addRow(fila);
            }
        }
        if (seleccion.equals("Editoriales")) {
            String sql = "SELECT * FROM editorial WHERE nombre LIKE ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + busqueda + "%");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Object[] fila = new Object[2];
                fila[0] = rs.getInt("id_editorial");
                fila[1] = rs.getString("nombre");
                modelo.addRow(fila);
            }
        }
        if (seleccion.equals("Categorías")) {
            String sql = "SELECT * FROM categoria WHERE nombre LIKE ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + busqueda + "%");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Object[] fila = new Object[2];
                fila[0] = rs.getInt("id_categoria");
                fila[1] = rs.getString("nombre");
                modelo.addRow(fila);
            }
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al filtrar tabla.");
        e.printStackTrace();
    }
        
    }
    
}
    

