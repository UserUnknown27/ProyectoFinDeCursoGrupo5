/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestor.de.bibliotecas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author df335
 */
public class Libro {
    private String titulo;
    private String isbn;
    private double precio;
    private int stock;
    private String editorial;
    private String categoria;
    private int id_editorial;
    private int id_categoria;

    /**
     * @return the titulo
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * @param titulo the titulo to set
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * @return the isbn
     */
    public String getIsbn() {
        return isbn;
    }

    /**
     * @param isbn the isbn to set
     */
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    /**
     * @return the precio
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * @param precio the precio to set
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    /**
     * @return the stock
     */
    public int getStock() {
        return stock;
    }

    /**
     * @param stock the stock to set
     */
    public void setStock(int stock) {
        this.stock = stock;
    }

    /**
     * @return the editorial
     */
    public String getEditorial() {
        return editorial;
    }

    /**
     * @param editorial the editorial to set
     */
    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    /**
     * @return the categoria
     */
    public String getCategoria() {
        return categoria;
    }

    /**
     * @param categoria the categoria to set
     */
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    
    public void AgregarLibro(){
        
        Connection con = Conexion.conectar();
        //INSERTAR EDITORIAL
        try{
        String insertar_editorial = "INSERT INTO editorial(nombre) VALUES(?)";
        PreparedStatement ps = con.prepareStatement(insertar_editorial);
        ps.setString(1, this.editorial);
        ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
        
        //OBTENER ID DE LA EDITORIAL
        try{
            
            String obtener_id_editorial = "SELECT id_editorial FROM editorial WHERE nombre = ?"; 
            PreparedStatement ps = con.prepareStatement(obtener_id_editorial);
            ps.setString(1, this.editorial);
            
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                this.id_editorial = rs.getInt(1);
            }  
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
        //INSERTAR CATEGORIA
        try{
            String insertar_categoria = "INSERT INTO categoria(nombre) VALUES(?)";
            PreparedStatement ps = con.prepareStatement(insertar_categoria);
            ps.setString(1, this.categoria);
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
        
        //OBTENER ID DE LA CATEGORIA
        try{
            
            String obtener_id_categoria = "SELECT id_categoria FROM categoria WHERE nombre = ?"; 
            PreparedStatement ps = con.prepareStatement(obtener_id_categoria);
            ps.setString(1, this.categoria);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                this.id_categoria = rs.getInt(1);
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
        
        //INSERTAR LIBRO
        String insertar = "INSERT INTO libro(titulo,isbn,precio,stock,id_editorial,id_categoria) VALUES (?,?,?,?,?,?)";
        try{
            PreparedStatement ps = con.prepareStatement(insertar);
            ps.setString(1, this.titulo);
            ps.setString(2, this.isbn);
            ps.setDouble(3, this.precio);
            ps.setInt(4, this.stock);
            ps.setInt(5, this.id_editorial);
            ps.setInt(6, this.id_categoria);
            ps.executeUpdate();  
            JOptionPane.showMessageDialog(null, "Libro añadido correctamente.");
        } catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al agregar libro.");
            e.printStackTrace();
        }
    }
    
   public void CargarLibros(JComboBox lista){
       Connection con = Conexion.conectar();
       String sql = "SELECT isbn, titulo FROM libro";
       try{
          lista.removeAllItems();
          lista.addItem("                 --  Inserte un Libro  --");
          PreparedStatement ps = con.prepareStatement(sql);
          ResultSet rs = ps.executeQuery();
          while(rs.next()){
              String isbn = rs.getString("isbn");
              String titulo = rs.getString("titulo");
              String libro = isbn + " | " + titulo;
              lista.addItem(libro);
          }
           
       }catch(Exception e){
           JOptionPane.showMessageDialog(null, "Error al cargar la lista de libros.");
           e.printStackTrace();
       }
   }
   
   public void MostrarDatos(JComboBox lista, JTextField titulo, JTextField precio, JTextField stock, JTextField categoria, JTextField editorial){
       
       if(lista.getSelectedItem() == null){
           return;
       }
       
       String seleccion = lista.getSelectedItem().toString();
       
       String[] dato= seleccion.split("\\|");
       
       
       try{
           
           String sql = "SELECT * FROM libro WHERE isbn = ?";
           
           Connection con = Conexion.conectar();
           
           PreparedStatement ps = con.prepareStatement(sql);
           ps.setString(1, dato[0]);
           
           ResultSet rs = ps.executeQuery();
           if(rs.next()){
               
               //OBTENGO TODOS LOS DATOS
               String tit = rs.getString("titulo");
               double prec = rs.getDouble("precio");
               int sto = rs.getInt("stock");
               int id_cat = rs.getInt("id_categoria");
               int id_edit = rs.getInt("id_editorial");
               
               
               // OBTENER E INTRODUCIR EN LOS CAMPOS DE TEXTO LOS NOMBRES DE CATEGORIA Y EDITORIAL A PARTIR DE SU ID 
               
               // SACO EL NOMBRE DE CATEGORIA PARA PODER METERLOS EN LOS CAMPOS DE TEXTO
               String obtener_id_categoria = "SELECT nombre FROM categoria WHERE id_categoria = ?"; 
               PreparedStatement ps1 = con.prepareStatement(obtener_id_categoria);
               ps1.setInt(1, id_cat);
               ResultSet rs1 = ps1.executeQuery();
               if(rs1.next()){
                String cat = rs1.getString("nombre");
                //ASIGNO EL VALOR DE CATEGORÍA EN EL CAMPO CORRESPONDIENTE
                categoria.setText(cat);
            }
               
               // SACO EL NOMBRE DE EDITORIAL PARA PODER METERLOS EN LOS CAMPOS DE TEXTO
               String obtener_id_editorial = "SELECT nombre FROM editorial WHERE id_editorial = ?"; 
               PreparedStatement ps2 = con.prepareStatement(obtener_id_editorial);
               ps2.setInt(1, id_edit);
               ResultSet rs2 = ps2.executeQuery();
               if(rs2.next()){
                String cat = rs2.getString("nombre");
                //ASIGNO EL VALOR DE LA EDITORIAL EN EL CAMPO CORRESPONDIENTE
                editorial.setText(cat);
            }
               
               //ASIGNO LOS DEMAS VALORES A LOS CAMPOS DE TEXTO PARA QUE EL USUARIO LOS VEA Y MODIFIQUE
               titulo.setText(tit);
               precio.setText(String.valueOf(prec));
               stock.setText(String.valueOf(sto));
           }
           else{
               //SI NO SE ENCUENTRA EL LIBRO EN LA BD, SE DEJA TODO EN BLANCO
               titulo.setText("");
               precio.setText(String.valueOf(""));
               stock.setText(String.valueOf(""));
               categoria.setText("");
               editorial.setText("");
           }
           
       }catch(Exception e){
           e.printStackTrace();
       }
       
   }
   
    public void ActualizarDatos(JComboBox lista, JTextField titulo, JTextField precio, JTextField stock, JTextField categoria, JTextField editorial){
    
    Connection con = Conexion.conectar();
    
    if(lista.getSelectedItem() == null){
        return;
    }
    
    if(lista.getSelectedItem().toString().equals("                 --  Inserte un Libro  --")){
        JOptionPane.showMessageDialog(null, "Seleccione un libro por favor.");
        return;
    }
    
    if(titulo.getText().equals("") || precio.getText().equals("") || stock.getText().equals("") || categoria.getText().equals("") || editorial.getText().equals("")){
        JOptionPane.showMessageDialog(null, "Debes rellenar todos los campos.");
        return;
    }
    
    if(Double.parseDouble(precio.getText()) < 0){
        JOptionPane.showMessageDialog(null, "El precio no puede ser negativo.");
        return;
    }
    
    if(stock.getText().contains(".")){
        JOptionPane.showMessageDialog(null,"El stock no puede tener decimales.");
        return; 
    }
        
    if(stock.getText().contains(",")){
        JOptionPane.showMessageDialog(null,"El stock no puede tener decimales.");
        return; 
    }
    
    if(Integer.parseInt(stock.getText()) < 0){
        JOptionPane.showMessageDialog(null, "El stock no puede ser negativo.");
        return;
    }
    
    // OBTENER ISBN
    String seleccion = lista.getSelectedItem().toString();
    String[] dato = seleccion.split("\\|");
    String isbn = dato[0].trim();
    
    int id_editorial = 0;
    int id_categoria = 0;
    
    // BUSCAR EDITORIAL, SI NO HAY, CREARLA
    try {
        String nombreEditorial = editorial.getText().trim();
        String obtener_id_editorial = "SELECT id_editorial FROM editorial WHERE nombre = ?"; 
        PreparedStatement ps = con.prepareStatement(obtener_id_editorial);
        ps.setString(1, nombreEditorial);
        
        ResultSet rs = ps.executeQuery();
        if(rs.next()){
            id_editorial = rs.getInt("id_editorial");
        } else {
            
            String insertar_editorial = "INSERT INTO editorial(nombre) VALUES(?)";
            PreparedStatement ps1 = con.prepareStatement(insertar_editorial, java.sql.Statement.RETURN_GENERATED_KEYS);
            ps1.setString(1, nombreEditorial);
            ps1.executeUpdate();
            
            ResultSet rs1 = ps1.getGeneratedKeys();
            if(rs1.next()){
                id_editorial = rs1.getInt(1);
            }
        }
    } catch(Exception e){
        e.printStackTrace();
    }

    // BUSCAR CATEGORIA, SI NO HAY, CREARLA
    try {
        String nombreCategoria = categoria.getText().trim();
        String obtener_id_categoria = "SELECT id_categoria FROM categoria WHERE nombre = ?"; 
        PreparedStatement ps = con.prepareStatement(obtener_id_categoria);
        ps.setString(1, nombreCategoria);
        
        ResultSet rs = ps.executeQuery();
        if(rs.next()){
            id_categoria = rs.getInt("id_categoria");
        } else {
            // ARREGLADO: Insertamos y pedimos el ID generado automáticamente
            String insertar_categoria = "INSERT INTO categoria(nombre) VALUES(?)";
            PreparedStatement ps1 = con.prepareStatement(insertar_categoria, java.sql.Statement.RETURN_GENERATED_KEYS);
            ps1.setString(1, nombreCategoria);
            ps1.executeUpdate();
            
            ResultSet rsKeys = ps1.getGeneratedKeys();
            if(rsKeys.next()){
                id_categoria = rsKeys.getInt(1);
            }
        }
    } catch(Exception e){
        e.printStackTrace();
    }
    
    // ACTUALIZAR TODOS LOS DATOS
    try {
        String sql = "UPDATE libro SET isbn = ?, titulo = ?, precio = ?, stock = ?, id_categoria = ?, id_editorial = ? WHERE isbn = ?";
        PreparedStatement ps = con.prepareStatement(sql);
        
        ps.setString(1, isbn);
        ps.setString(2, titulo.getText());
        ps.setDouble(3, Double.parseDouble(precio.getText()));
        ps.setInt(4, Integer.parseInt(stock.getText()));
        ps.setInt(5, id_categoria); 
        ps.setInt(6, id_editorial); 
        ps.setString(7, isbn);
        
        ps.executeUpdate();
        JOptionPane.showMessageDialog(null, "Datos actualizados.");
        
        //DEJAMOS SELECCIONADO EL LIBRO CON LOS DATOS NUEVOS
        
        int posicion = lista.getSelectedIndex();
        
        String datos_nuevos = isbn + "\\|" + titulo.getText();
        
        lista.removeItemAt(posicion);
        lista.insertItemAt(datos_nuevos, posicion);
        
        lista.setSelectedIndex(posicion);
        
        
    } catch(Exception e){
        JOptionPane.showMessageDialog(null, "Error al actualizar los datos.");
        e.printStackTrace();
    }
}
    
    public void FiltroLibros(JComboBox lista, JTextField filtro){
        
        String busqueda = filtro.getText();
        Connection con = Conexion.conectar();
        
        try{
            
            lista.removeAllItems();
            
            if(busqueda.equals("")){
            lista.addItem("                 --  Inserte un Libro  --");
            }
            
            String sql = "SELECT isbn, titulo FROM libro WHERE titulo LIKE ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + busqueda + "%");
            
            ResultSet rs = ps.executeQuery();
            String isbn;
            String titulo;
            while(rs.next()){
                isbn = rs.getString("isbn");
                titulo = rs.getString("titulo");
                String resultado = isbn + " | " + titulo;
                lista.addItem(resultado);
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    
    public void EliminarLibro(JComboBox lista){
        
        Connection con = Conexion.conectar();
        String seleccion = lista.getSelectedItem().toString();
        
        String [] dato = seleccion.split("\\|");
        String isbn = dato[0];
        
        try{
           
            String sql = "DELETE FROM libro WHERE isbn = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, isbn);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Libro eliminado correctamente.");
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al eliminar libro.");
            e.printStackTrace();
        }
        
    }
    
}
