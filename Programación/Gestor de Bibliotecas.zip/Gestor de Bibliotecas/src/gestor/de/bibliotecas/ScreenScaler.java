package gestor.de.bibliotecas;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Window;

public class ScreenScaler {

    public static void scale(Component comp, double factor) {
        if (comp == null) return;

        bakeGroupLayouts(comp, factor);
        scaleRecursive(comp, factor);

        if (comp instanceof Window) {
            Window window = (Window) comp;

            if (!window.isDisplayable()) {
                window.addNotify();
            }

            Dimension minSize = window.getMinimumSize();
            if (minSize.width > 0 && minSize.height > 0) {
                window.setMinimumSize(new Dimension(
                    (int) Math.round(minSize.width * factor),
                    (int) Math.round(minSize.height * factor)
                ));
            }

            window.pack();
            window.setLocationRelativeTo(null);
            window.validate();
            window.repaint();
        }
    }

    private static void bakeGroupLayouts(Component comp, double factor) {
        if (!(comp instanceof Container)) return;
        Container c = (Container) comp;

        if (c.getLayout() instanceof javax.swing.GroupLayout) {
            Dimension pref = c.getPreferredSize();
            c.setSize(pref);
            c.doLayout();

            Component[] children = c.getComponents();
            Rectangle[] bounds = new Rectangle[children.length];
            for (int i = 0; i < children.length; i++) {
                bounds[i] = children[i].getBounds();
            }

            c.setLayout(null);
            for (int i = 0; i < children.length; i++) {
                Rectangle r = bounds[i];
                children[i].setBounds(
                    (int) Math.round(r.x * factor),
                    (int) Math.round(r.y * factor),
                    (int) Math.round(r.width * factor),
                    (int) Math.round(r.height * factor)
                );
            }

            c.setPreferredSize(new Dimension(
                (int) Math.round(pref.width * factor),
                (int) Math.round(pref.height * factor)
            ));
        }

        for (Component child : c.getComponents()) {
            bakeGroupLayouts(child, factor);
        }
    }

    private static void scaleRecursive(Component comp, double factor) {
        Font f = comp.getFont();
        if (f != null) {
            comp.setFont(f.deriveFont((float) (f.getSize() * factor)));
        }

        if (comp instanceof javax.swing.JLabel) {
            javax.swing.JLabel label = (javax.swing.JLabel) comp;
            javax.swing.Icon icon = label.getIcon();
            
            if (icon instanceof javax.swing.ImageIcon) {
                javax.swing.ImageIcon imageIcon = (javax.swing.ImageIcon) icon;
                java.awt.Image image = imageIcon.getImage();
                
                int newWidth = (int) Math.round(imageIcon.getIconWidth() * factor);
                int newHeight = (int) Math.round(imageIcon.getIconHeight() * factor);
                
                if (newWidth > 0 && newHeight > 0) {
                    java.awt.Image scaledImage = image.getScaledInstance(newWidth, newHeight, java.awt.Image.SCALE_SMOOTH);
                    label.setIcon(new javax.swing.ImageIcon(scaledImage));
                }
            }
        }

        if (comp instanceof javax.swing.JTable) {
            javax.swing.JTable table = (javax.swing.JTable) comp;
            table.setRowHeight((int) Math.round(table.getRowHeight() * factor));
            try {
                for (int i = 0; i < table.getColumnModel().getColumnCount(); i++) {
                    javax.swing.table.TableColumn col = table.getColumnModel().getColumn(i);
                    col.setPreferredWidth((int) Math.round(col.getPreferredWidth() * factor));
                }
            } catch (Exception ex) {
            }
        }

        if (comp instanceof Container) {
            Container parent = (Container) comp;
            Object layout = parent.getLayout();

            if (layout != null && layout.getClass().getName().equals("org.netbeans.lib.awtextra.AbsoluteLayout")) {
                scaleAbsoluteLayout(parent, layout, factor);
            }

            for (Component child : parent.getComponents()) {
                scaleRecursive(child, factor);
            }
        }
    }

    private static void scaleAbsoluteLayout(Container parent, Object layout, double factor) {
        Component[] children = parent.getComponents();

        java.util.Hashtable constraintsTable = null;
        try {
            java.lang.reflect.Field field = layout.getClass().getDeclaredField("constraints");
            field.setAccessible(true);
            constraintsTable = (java.util.Hashtable) field.get(layout);
        } catch (Exception ex) {
            System.err.println("Could not read AbsoluteLayout constraints: " + ex.getMessage());
            return;
        }
        if (constraintsTable == null) return;

        Class<?> constraintsClass;
        try {
            constraintsClass = Class.forName("org.netbeans.lib.awtextra.AbsoluteConstraints");
        } catch (Exception ex) {
            System.err.println("Could not load AbsoluteConstraints class: " + ex.getMessage());
            return;
        }

        for (Component child : children) {
            Object cons = constraintsTable.get(child);
            if (cons != null) {
                try {
                    int x = (Integer) cons.getClass().getMethod("getX").invoke(cons);
                    int y = (Integer) cons.getClass().getMethod("getY").invoke(cons);
                    int w = (Integer) cons.getClass().getMethod("getWidth").invoke(cons);
                    int h = (Integer) cons.getClass().getMethod("getHeight").invoke(cons);

                    int sx = (int) Math.round(x * factor);
                    int sy = (int) Math.round(y * factor);
                    int sw = w > 0 ? (int) Math.round(w * factor) : w;
                    int sh = h > 0 ? (int) Math.round(h * factor) : h;

                    java.lang.reflect.Constructor<?> constr =
                        constraintsClass.getConstructor(int.class, int.class, int.class, int.class);
                    Object scaledCons = constr.newInstance(sx, sy, sw, sh);

                    layout.getClass().getMethod("addLayoutComponent", Component.class, Object.class)
                        .invoke(layout, child, scaledCons);
                } catch (Exception ex) {
                    System.err.println("Error scaling constraint: " + ex.getMessage());
                }
            }
        }
        parent.revalidate();
        parent.repaint();
    }
}
