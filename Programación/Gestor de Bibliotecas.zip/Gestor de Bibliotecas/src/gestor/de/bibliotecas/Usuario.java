/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestor.de.bibliotecas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author df335
 */
public class Usuario {
    
    public void crearusuario(String nombre , String dni, String correo , String contraseña){
        String nuevo = "INSERT INTO usuario (tipo, nombre_completo, dni, email, contraseña) VALUES ('cliente', ?, ?, ?, ?)";
        
        try{
           Connection con = Conexion.conectar();
           PreparedStatement ps = con.prepareStatement(nuevo);
           ps.setString(1, nombre);
           ps.setString(2, dni);
           ps.setString(3, correo);
           ps.setString(4, contraseña);
           ps.executeUpdate();
           JOptionPane.showMessageDialog(null, "Cuenta creada correctamente.");
        } 
        catch(SQLException ex)
        {
            JOptionPane.showMessageDialog(null, "Error al crear cuenta.");
        }
    }
    
    public void iniciarsesion(String correo, String contraseña, javax.swing.JFrame pantalla){
        String acceder = "SELECT tipo, nombre_completo FROM usuario WHERE email=? AND contraseña=?";
        
        try(Connection con = Conexion.conectar();
            PreparedStatement ps = con.prepareStatement(acceder)){
            ps.setString(1, correo);
            ps.setString(2, contraseña);
            
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                String tipo = rs.getString("tipo");
                String nombre = rs.getString("nombre_completo");
            if(tipo.equals("cliente")){
                new Pantalla3(nombre, correo).setVisible(true);
                pantalla.dispose();
            } else{
                new Pantalla2(nombre).setVisible(true);
                pantalla.dispose();
            }
            } else {
                JOptionPane.showMessageDialog(null, "Datos incorrectos.");
            }
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,"Error al iniciar sesion.");  
        }
            
    }
    
}
