package gestor.de.bibliotecas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.junit.Test;
import static org.junit.Assert.*;

public class Pruebas_Unitarias {

    @Test
    public void testValidacionEmailCorrecto() {
        String emailValido = "juanperez@gmail.com";
        String regex = "^[A-Za-z0-9]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        assertTrue(java.util.regex.Pattern.matches(regex, emailValido));
    }

    @Test
    public void testValidacionEmailIncorrecto() {
        String emailInvalido = "juan.perez.gmail.com";
        String regex = "^[A-Za-z0-9]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        assertFalse(java.util.regex.Pattern.matches(regex, emailInvalido));
    }

    @Test
    public void testValidacionTelefonoCorrecto() {
        String telfValido = "612345678";
        String regex = "^[0-9]{9}$";
        assertTrue(java.util.regex.Pattern.matches(regex, telfValido));
    }

    @Test
    public void testCrearUsuarioEnBaseDatos() {
        Usuario gestionUsuario = new Usuario();
        String nombrePrueba = "Test User";
        String dniPrueba = "99999999Z";
        String correoPrueba = "test_unitario@biblioteca.com";
        String passPrueba = "12345";
        
        gestionUsuario.crearusuario(nombrePrueba, dniPrueba, correoPrueba, passPrueba);
        
        String sqlBuscar = "SELECT nombre_completo FROM usuario WHERE email = ?";
        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sqlBuscar)) {
            
            ps.setString(1, correoPrueba);
            try (ResultSet rs = ps.executeQuery()) {
                assertTrue(rs.next());
                assertEquals(nombrePrueba, rs.getString("nombre_completo"));
            }
            
            String sqlBorrar = "DELETE FROM usuario WHERE email = ?";
            try (PreparedStatement psBorrar = con.prepareStatement(sqlBorrar)) {
                psBorrar.setString(1, correoPrueba);
                psBorrar.executeUpdate();
            }

        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    @Test
    public void testAgregarLibroEnBaseDatos() {
        Libro libroTest = new Libro();
        libroTest.setTitulo("Libro Test JUnit");
        libroTest.setIsbn("000-000-000");
        libroTest.setPrecio(15.50);
        libroTest.setStock(3);
        libroTest.setEditorial("Editorial Test");
        libroTest.setCategoria("Categoria Test");
        
        libroTest.AgregarLibro();
        
        String sqlBuscar = "SELECT titulo FROM libro WHERE isbn = ?";
        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sqlBuscar)) {
            
            ps.setString(1, "000-000-000");
            try (ResultSet rs = ps.executeQuery()) {
                assertTrue(rs.next());
                assertEquals("Libro Test JUnit", rs.getString("titulo"));
            }
            
            String sqlBorrarLibro = "DELETE FROM libro WHERE isbn = ?";
            try (PreparedStatement psBorrar = con.prepareStatement(sqlBorrarLibro)) {
                psBorrar.setString(1, "000-000-000");
                psBorrar.executeUpdate();
            }
            
            String sqlBorrarEditorial = "DELETE FROM editorial WHERE nombre = 'Editorial Test'";
            try (PreparedStatement psBorrarEd = con.prepareStatement(sqlBorrarEditorial)) {
                psBorrarEd.executeUpdate();
            }
            
            String sqlBorrarCategoria = "DELETE FROM categoria WHERE nombre = 'Categoria Test'";
            try (PreparedStatement psBorrarCat = con.prepareStatement(sqlBorrarCategoria)) {
                psBorrarCat.executeUpdate();
            }

        } catch (Exception e) {
            fail(e.getMessage());
        }
    }
}
